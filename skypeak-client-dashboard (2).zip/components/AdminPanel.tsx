
import React, { useState } from 'react';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Search, 
  X, 
  Check, 
  Shield, 
  Server, 
  Lock, 
  Globe, 
  DollarSign, 
  BarChart, 
  User as UserIcon, 
  Calendar, 
  FileText, 
  Activity, 
  Zap, 
  Cpu, 
  Target,
  Smartphone,
  Briefcase,
  Settings,
  RefreshCw,
  Database
} from 'lucide-react';
import { ClientData, Invoice, ActivityLog, WebsitePayment, MaintenanceTask, KeywordRanking } from '../types';

interface AdminPanelProps {
  clients: ClientData[];
  setClients: React.Dispatch<React.SetStateAction<ClientData[]>>;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ clients, setClients }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'IDENTITY' | 'SEO' | 'INFRA' | 'BILLING' | 'PROJECT' | 'MAINTENANCE'>('IDENTITY');
  
  const initialForm: ClientData = {
    id: '',
    name: '',
    username: '',
    password: '',
    email: '',
    domain: '',
    seoScore: 75,
    seoImpressions: 12000,
    seoCTR: 3.5,
    seoTotalKeywords: 50,
    seoRankings: [],
    trafficData: [40, 30, 45, 70, 65, 90],
    organicPercent: 65,
    directPercent: 20,
    referralPercent: 15,
    speedIndex: '1.2s',
    mobileUX: 'Good',
    domainExpiry: new Date(Date.now() + 31536000000).toISOString().split('T')[0],
    serverExpiry: new Date(Date.now() + 31536000000).toISOString().split('T')[0],
    registrar: 'GoDaddy',
    serverIP: '192.168.1.1',
    serverLocation: 'USA - NY',
    phpVersion: '8.3.4',
    osVersion: 'Ubuntu 22.04 LTS',
    dbVersion: 'MariaDB 10.11',
    maintenanceStatus: 'Up to Date',
    maintenancePlanName: 'Professional Care',
    maintenanceNextCharge: 'Nov 01, 2025',
    maintenanceSecurityScore: 100,
    maintenanceBackupStatus: 'Daily',
    maintenancePerformanceResponse: '0.8s',
    maintenanceTasks: [],
    activityLog: [],
    monthlyPrice: 199.00,
    maintenancePrice: 50.00,
    invoices: [],
    websitePayments: []
  };

  const [form, setForm] = useState<ClientData>(initialForm);

  const openAdd = () => {
    setForm(initialForm);
    setEditingId(null);
    setActiveSubTab('IDENTITY');
    setIsModalOpen(true);
  };

  const openEdit = (client: ClientData) => {
    setForm(client);
    setEditingId(client.id);
    setActiveSubTab('IDENTITY');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      setClients(clients.map(c => c.id === editingId ? form : c));
    } else {
      setClients([...clients, { ...form, id: Date.now().toString() }]);
    }
    setIsModalOpen(false);
  };

  const removeClient = (id: string) => {
    if (confirm("Permanently delete this account?")) {
      setClients(clients.filter(c => c.id !== id));
    }
  };

  const addInvoice = () => {
    const newInv: Invoice = {
      id: `INV-${Math.floor(Math.random() * 9000) + 1000}`,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      amount: form.monthlyPrice + form.maintenancePrice,
      status: 'Pending',
      type: 'Monthly Retainer'
    };
    setForm({ ...form, invoices: [newInv, ...form.invoices] });
  };

  const addWebsitePayment = () => {
    const newPay: WebsitePayment = {
      id: `WS-${Math.floor(Math.random() * 900) + 100}`,
      title: 'New Milestone Phase',
      amount: 1000,
      status: 'Pending',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' })
    };
    setForm({ ...form, websitePayments: [newPay, ...form.websitePayments] });
  };

  const addMaintenanceTask = () => {
    const newTask: MaintenanceTask = {
      id: Date.now().toString(),
      name: 'New Maintenance Task',
      status: 'Scheduled',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      icon: 'Settings'
    };
    setForm({ ...form, maintenanceTasks: [newTask, ...form.maintenanceTasks] });
  };

  const addRanking = () => {
    const newRanking: KeywordRanking = {
      id: Date.now().toString(),
      term: 'New Keyword',
      rank: 1,
      change: '+1 POS'
    };
    setForm({ ...form, seoRankings: [...form.seoRankings, newRanking] });
  };

  const addActivity = () => {
    const newTask: ActivityLog = {
      id: Date.now().toString(),
      task: 'New System Update',
      date: 'Just now',
      icon: 'CheckCircle2',
      color: 'emerald'
    };
    setForm({ ...form, activityLog: [newTask, ...form.activityLog] });
  };

  const handleTrafficChange = (val: string) => {
    const data = val.split(',').map(v => parseInt(v.trim()) || 0);
    setForm({ ...form, trafficData: data });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Admin <span className="text-orange-500">Center</span></h2>
          <p className="text-slate-500 font-medium">Control every metric of the client experience.</p>
        </div>
        <button onClick={openAdd} className="px-8 py-4 bg-orange-500 text-white rounded-2xl font-black flex items-center gap-2 hover:bg-orange-600 transition-all shadow-xl shadow-orange-500/20 active:scale-95">
          <Plus className="w-5 h-5" /> Initialize Client
        </button>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl shadow-slate-200/40 overflow-hidden">
        <div className="p-8 border-b border-slate-100 flex flex-col md:flex-row items-center justify-between bg-slate-50/50 gap-4">
          <div className="relative w-full">
            <Search className="absolute left-4 top-3.5 w-4 h-4 text-slate-400" />
            <input type="text" placeholder="Search accounts..." className="w-full bg-white border border-slate-200 rounded-xl py-3 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-orange-500" />
          </div>
          <div className="flex gap-4">
            <div className="text-center px-4"><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Clients</p><p className="text-xl font-black text-slate-900">{clients.length}</p></div>
            <div className="text-center px-4"><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Avg SEO</p><p className="text-xl font-black text-orange-500">82%</p></div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Profile</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Auth</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Health</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Revenue</th>
                <th className="px-8 py-5"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {clients.map((client) => (
                <tr key={client.id} className="hover:bg-slate-50/40 group transition-all">
                  <td className="px-8 py-6"><div className="font-bold text-slate-900">{client.name}</div><div className="text-xs text-slate-500">{client.domain}</div></td>
                  <td className="px-8 py-6"><div className="text-sm font-bold text-slate-700">{client.username}</div><div className="text-[10px] text-slate-400 font-mono">{client.password}</div></td>
                  <td className="px-8 py-6"><div className="flex items-center gap-1.5"><span className="w-2 h-2 bg-emerald-500 rounded-full"></span><span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Healthy</span></div></td>
                  <td className="px-8 py-6"><div className="font-black text-slate-900">${(client.monthlyPrice + client.maintenancePrice).toFixed(0)}</div></td>
                  <td className="px-8 py-6 text-right"><div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity"><button onClick={() => openEdit(client)} className="p-2 text-slate-400 hover:text-orange-500 border border-slate-100 rounded-lg"><Edit2 className="w-4 h-4" /></button><button onClick={() => removeClient(client.id)} className="p-2 text-slate-400 hover:text-red-500 border border-slate-100 rounded-lg"><Trash2 className="w-4 h-4" /></button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md">
          <div className="bg-white rounded-[2.5rem] w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl border border-white/20">
            <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-white z-10">
              <div><h3 className="text-2xl font-black text-slate-900">{editingId ? 'Edit Configuration' : 'Create Global Asset'}</h3><p className="text-sm text-slate-500">Configure search rankings, infrastructure and activity logs.</p></div>
              <button onClick={() => setIsModalOpen(false)} className="p-3 hover:bg-slate-100 rounded-full transition-colors"><X className="w-6 h-6 text-slate-400" /></button>
            </div>

            <div className="flex border-b border-slate-100 bg-slate-50/50 px-8 overflow-x-auto no-scrollbar">
              {[
                { id: 'IDENTITY', label: 'Identity & Access', icon: UserIcon },
                { id: 'SEO', label: 'Growth & SEO', icon: BarChart },
                { id: 'INFRA', label: 'Infrastructure', icon: Server },
                { id: 'BILLING', label: 'Retainers', icon: FileText },
                { id: 'PROJECT', label: 'Project Billing', icon: Briefcase },
                { id: 'MAINTENANCE', label: 'Maintenance', icon: Settings }
              ].map(tab => (
                <button 
                  key={tab.id}
                  onClick={() => setActiveSubTab(tab.id as any)}
                  className={`flex items-center gap-2 py-5 px-6 font-black text-[10px] uppercase tracking-[0.2em] transition-all relative whitespace-nowrap ${activeSubTab === tab.id ? 'text-orange-500' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  <tab.icon className="w-4 h-4" /> {tab.label}
                  {activeSubTab === tab.id && <div className="absolute bottom-0 left-0 w-full h-1 bg-orange-500 rounded-t-full shadow-[0_0_12px_rgba(249,115,22,0.8)]"></div>}
                </button>
              ))}
            </div>
            
            <form onSubmit={handleSubmit} className="p-10 flex-1 overflow-y-auto space-y-12">
              {activeSubTab === 'IDENTITY' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10 animate-in slide-in-from-left-4 duration-300">
                  <div className="space-y-6">
                    <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><Globe className="w-5 h-5 text-orange-500" /> Basic Details</h4>
                    <div className="space-y-4">
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Client Official Name</label><input required type="text" value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-orange-500 outline-none" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Primary Domain</label><input required type="text" value={form.domain} onChange={e => setForm({...form, domain: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" placeholder="example.com" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Contact Email</label><input required type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                    </div>
                  </div>
                  <div className="space-y-6">
                    <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><Lock className="w-5 h-5 text-blue-500" /> Portal Credentials</h4>
                    <div className="space-y-4">
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Username</label><input required type="text" value={form.username} onChange={e => setForm({...form, username: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Secure Password</label><input required type="text" value={form.password} onChange={e => setForm({...form, password: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                    </div>
                  </div>
                </div>
              )}

              {activeSubTab === 'SEO' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10 animate-in slide-in-from-left-4 duration-300">
                  <div className="space-y-6">
                    <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><Target className="w-5 h-5 text-emerald-500" /> Organic Metrics</h4>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">SEO Score (%)</label><input type="number" value={form.seoScore} onChange={e => setForm({...form, seoScore: Number(e.target.value)})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Impressions</label><input type="number" value={form.seoImpressions} onChange={e => setForm({...form, seoImpressions: Number(e.target.value)})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Traffic Acquisition Trend (Trend Line Data, Comma separated)</label>
                      <input type="text" value={form.trafficData.join(', ')} onChange={e => handleTrafficChange(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" placeholder="40, 30, 45, 70, 65, 90" />
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Organic %</label><input type="number" value={form.organicPercent} onChange={e => setForm({...form, organicPercent: Number(e.target.value)})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Direct %</label><input type="number" value={form.directPercent} onChange={e => setForm({...form, directPercent: Number(e.target.value)})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Referral %</label><input type="number" value={form.referralPercent} onChange={e => setForm({...form, referralPercent: Number(e.target.value)})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                    </div>
                  </div>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><Target className="w-5 h-5 text-orange-500" /> Ranking Manager</h4>
                      <button type="button" onClick={addRanking} className="text-[10px] font-black text-orange-600 uppercase tracking-widest hover:underline">+ New Rank</button>
                    </div>
                    <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 no-scrollbar">
                      {form.seoRankings.map((rk, i) => (
                        <div key={rk.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-4 relative group">
                          <button 
                            type="button" 
                            onClick={() => setForm({...form, seoRankings: form.seoRankings.filter(r => r.id !== rk.id)})}
                            className="absolute top-4 right-4 text-slate-300 hover:text-red-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <div className="space-y-1">
                            <label className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em]">Keyword Term</label>
                            <input 
                              type="text" 
                              value={rk.term} 
                              onChange={e => {
                                const newList = [...form.seoRankings];
                                newList[i].term = e.target.value;
                                setForm({...form, seoRankings: newList});
                              }}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                              <label className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em]">Rank #</label>
                              <input 
                                type="number" 
                                value={rk.rank} 
                                onChange={e => {
                                  const newList = [...form.seoRankings];
                                  newList[i].rank = Number(e.target.value);
                                  setForm({...form, seoRankings: newList});
                                }}
                                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em]">Change Status</label>
                              <input 
                                type="text" 
                                value={rk.change} 
                                onChange={e => {
                                  const newList = [...form.seoRankings];
                                  newList[i].change = e.target.value;
                                  setForm({...form, seoRankings: newList});
                                }}
                                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold"
                                placeholder="+2 POS"
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeSubTab === 'INFRA' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10 animate-in slide-in-from-left-4 duration-300">
                  <div className="space-y-6">
                    <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><Zap className="w-5 h-5 text-blue-500" /> Cloud Configuration</h4>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Domain Expiry Date</label><input type="date" value={form.domainExpiry} onChange={e => setForm({...form, domainExpiry: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Hosting Renewal Date</label><input type="date" value={form.serverExpiry} onChange={e => setForm({...form, serverExpiry: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                    </div>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Server IP Address</label><input type="text" value={form.serverIP} onChange={e => setForm({...form, serverIP: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Registry Provider</label><input type="text" value={form.registrar} onChange={e => setForm({...form, registrar: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                    </div>
                    <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Datacenter Region</label><input type="text" value={form.serverLocation} onChange={e => setForm({...form, serverLocation: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                  </div>
                  <div className="space-y-6">
                    <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><Cpu className="w-5 h-5 text-purple-500" /> Technical Stack</h4>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">PHP Version</label><input type="text" value={form.phpVersion} onChange={e => setForm({...form, phpVersion: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">OS Environment</label><input type="text" value={form.osVersion} onChange={e => setForm({...form, osVersion: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                      <div className="space-y-2 col-span-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Database Engine</label><input type="text" value={form.dbVersion} onChange={e => setForm({...form, dbVersion: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                    </div>
                  </div>
                </div>
              )}

              {activeSubTab === 'BILLING' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10 animate-in slide-in-from-left-4 duration-300">
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><DollarSign className="w-5 h-5 text-emerald-500" /> Subscription & Invoices</h4>
                      <button type="button" onClick={addInvoice} className="text-[10px] font-black text-orange-500 uppercase tracking-widest hover:underline">+ New Invoice</button>
                    </div>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">SEO Retainer ($)</label><input type="number" value={form.monthlyPrice} onChange={e => setForm({...form, monthlyPrice: Number(e.target.value)})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Maint. Fee ($)</label><input type="number" value={form.maintenancePrice} onChange={e => setForm({...form, maintenancePrice: Number(e.target.value)})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                    </div>
                    <div className="max-h-48 overflow-y-auto bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-2">
                      {form.invoices.map(inv => (
                        <div key={inv.id} className="flex items-center justify-between p-2 bg-white rounded-lg border border-slate-100 shadow-sm">
                          <span className="text-[10px] font-black">{inv.id} &bull; ${inv.amount}</span>
                          <button type="button" onClick={() => setForm({...form, invoices: form.invoices.filter(i => i.id !== inv.id)})} className="text-slate-300 hover:text-red-500"><Trash2 className="w-3 h-3" /></button>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><Activity className="w-5 h-5 text-orange-500" /> Maintenance Logs</h4>
                      <button type="button" onClick={addActivity} className="text-[10px] font-black text-orange-500 uppercase tracking-widest hover:underline">+ Add Entry</button>
                    </div>
                    <div className="max-h-[300px] overflow-y-auto bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
                      {form.activityLog.map(log => (
                        <div key={log.id} className="p-3 bg-white rounded-xl border border-slate-100 flex items-center justify-between">
                          <div><p className="text-xs font-bold text-slate-900">{log.task}</p><p className="text-[10px] text-slate-400 font-medium">{log.date}</p></div>
                          <button type="button" onClick={() => setForm({...form, activityLog: form.activityLog.filter(l => l.id !== log.id)})} className="text-slate-300 hover:text-red-500"><Trash2 className="w-3 h-3" /></button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeSubTab === 'PROJECT' && (
                <div className="space-y-8 animate-in slide-in-from-left-4 duration-300">
                  <div className="flex justify-between items-center">
                    <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><Briefcase className="w-5 h-5 text-indigo-500" /> Website Project Milestones</h4>
                    <button type="button" onClick={addWebsitePayment} className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">+ New Milestone</button>
                  </div>
                  <div className="space-y-4">
                    {form.websitePayments.length === 0 ? (
                      <div className="p-20 text-center border-2 border-dashed border-slate-200 rounded-[2rem]">
                        <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest">No project milestones defined.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {form.websitePayments.map((pay, i) => (
                          <div key={pay.id} className="bg-slate-50 rounded-[2rem] border border-slate-200 p-6 space-y-4 relative group">
                            <button 
                              type="button" 
                              onClick={() => setForm({...form, websitePayments: form.websitePayments.filter(p => p.id !== pay.id)})}
                              className="absolute top-4 right-4 p-2 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                            <div className="space-y-1">
                              <label className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em]">Phase Title</label>
                              <input 
                                type="text" 
                                value={pay.title} 
                                onChange={e => {
                                  const newList = [...form.websitePayments];
                                  newList[i].title = e.target.value;
                                  setForm({...form, websitePayments: newList});
                                }}
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <label className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em]">Amount ($)</label>
                                <input 
                                  type="number" 
                                  value={pay.amount} 
                                  onChange={e => {
                                    const newList = [...form.websitePayments];
                                    newList[i].amount = Number(e.target.value);
                                    setForm({...form, websitePayments: newList});
                                  }}
                                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em]">Status</label>
                                <select 
                                  value={pay.status}
                                  onChange={e => {
                                    const newList = [...form.websitePayments];
                                    newList[i].status = e.target.value as any;
                                    setForm({...form, websitePayments: newList});
                                  }}
                                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                                >
                                  <option value="Paid">Paid</option>
                                  <option value="Pending">Pending</option>
                                </select>
                              </div>
                            </div>
                            <div className="space-y-1">
                              <label className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em]">Due/Paid Date</label>
                              <input 
                                type="text" 
                                value={pay.date} 
                                onChange={e => {
                                  const newList = [...form.websitePayments];
                                  newList[i].date = e.target.value;
                                  setForm({...form, websitePayments: newList});
                                }}
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                                placeholder="Oct 30, 2025"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {activeSubTab === 'MAINTENANCE' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10 animate-in slide-in-from-left-4 duration-300">
                  <div className="space-y-6">
                    <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><Settings className="w-5 h-5 text-orange-500" /> General Maintenance Metrics</h4>
                    <div className="space-y-4">
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Plan Name</label><input type="text" value={form.maintenancePlanName} onChange={e => setForm({...form, maintenancePlanName: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Next Renewal Charge Date</label><input type="text" value={form.maintenanceNextCharge} onChange={e => setForm({...form, maintenanceNextCharge: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" placeholder="Nov 01, 2025" /></div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Security Score (%)</label><input type="number" value={form.maintenanceSecurityScore} onChange={e => setForm({...form, maintenanceSecurityScore: Number(e.target.value)})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" /></div>
                        <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Backup Status Text</label><input type="text" value={form.maintenanceBackupStatus} onChange={e => setForm({...form, maintenanceBackupStatus: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" placeholder="4 hours ago" /></div>
                      </div>
                      <div className="space-y-2"><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Avg Response Time</label><input type="text" value={form.maintenancePerformanceResponse} onChange={e => setForm({...form, maintenancePerformanceResponse: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm outline-none" placeholder="0.8s" /></div>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h4 className="text-lg font-black text-slate-900 flex items-center gap-2"><RefreshCw className="w-5 h-5 text-blue-500" /> Maintenance Task Log</h4>
                      <button type="button" onClick={addMaintenanceTask} className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline">+ New Task</button>
                    </div>
                    <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 no-scrollbar">
                      {form.maintenanceTasks.map((task, i) => (
                        <div key={task.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-4 relative group">
                          <button 
                            type="button" 
                            onClick={() => setForm({...form, maintenanceTasks: form.maintenanceTasks.filter(t => t.id !== task.id)})}
                            className="absolute top-4 right-4 text-slate-300 hover:text-red-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <input 
                            type="text" 
                            value={task.name} 
                            onChange={e => {
                              const newList = [...form.maintenanceTasks];
                              newList[i].name = e.target.value;
                              setForm({...form, maintenanceTasks: newList});
                            }}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold"
                            placeholder="Task Name"
                          />
                          <div className="grid grid-cols-3 gap-2">
                            <select 
                              value={task.status}
                              onChange={e => {
                                const newList = [...form.maintenanceTasks];
                                newList[i].status = e.target.value as any;
                                setForm({...form, maintenanceTasks: newList});
                              }}
                              className="bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-[10px] font-bold"
                            >
                              <option value="Completed">Completed</option>
                              <option value="Active">Active</option>
                              <option value="Scheduled">Scheduled</option>
                            </select>
                            <input 
                              type="text" 
                              value={task.date} 
                              onChange={e => {
                                const newList = [...form.maintenanceTasks];
                                newList[i].date = e.target.value;
                                setForm({...form, maintenanceTasks: newList});
                              }}
                              className="bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-[10px] font-bold"
                              placeholder="Date"
                            />
                            <select 
                              value={task.icon}
                              onChange={e => {
                                const newList = [...form.maintenanceTasks];
                                newList[i].icon = e.target.value as any;
                                setForm({...form, maintenanceTasks: newList});
                              }}
                              className="bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-[10px] font-bold"
                            >
                              <option value="Zap">Zap</option>
                              <option value="ShieldCheck">Security</option>
                              <option value="Database">Database</option>
                              <option value="RefreshCw">Refresh</option>
                              <option value="Settings">Settings</option>
                            </select>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-10 flex flex-col md:flex-row gap-4 border-t border-slate-100">
                <button type="submit" className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-black py-5 rounded-2xl transition-all flex items-center justify-center gap-3 shadow-2xl active:scale-[0.98]">
                  <Check className="w-6 h-6 text-orange-500" /> {editingId ? 'Push Updates to Dashboard' : 'Finalize Asset Deployment'}
                </button>
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-10 py-5 bg-slate-100 text-slate-600 font-bold rounded-2xl hover:bg-slate-200 transition-all">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
