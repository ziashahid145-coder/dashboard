
import React, { useState } from 'react';
import { AppTab, User, ClientData } from './types';
import Dashboard from './components/Dashboard';
import SEOSection from './components/SEOSection';
import DomainSection from './components/DomainSection';
import HostingSection from './components/HostingSection';
import PaymentsSection from './components/PaymentsSection';
import WebsitePaymentSection from './components/WebsitePaymentSection';
import MaintenanceSection from './components/MaintenanceSection';
import SupportSection from './components/SupportSection';
import AdminPanel from './components/AdminPanel';
import SourceCode from './components/SourceCode';
import { 
  Bell, 
  User as UserIcon, 
  LayoutDashboard, 
  Globe, 
  Server,
  CreditCard, 
  BarChart3, 
  Settings, 
  LifeBuoy,
  Users,
  Code,
  LogOut,
  Lock,
  ExternalLink,
  ShieldCheck,
  Facebook,
  Twitter,
  Linkedin,
  Mail,
  Briefcase
} from 'lucide-react';

const LOGO_URL = "https://skypeakdesigns.com/wp-content/uploads/2025/11/cropped-skypeak-designs.png";

const Footer: React.FC = () => (
  <footer className="bg-[#0f172a] text-slate-400 py-12 mt-auto border-t border-slate-800">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-8">
        <div className="col-span-1 md:col-span-2">
          <img src={LOGO_URL} alt="SkyPeak Designs" className="h-8 mb-6 brightness-0 invert opacity-80" />
          <p className="text-sm max-w-sm leading-relaxed mb-6">
            SkyPeak Designs provides industry-leading web solutions, high-authority SEO strategies, 
            and ultra-secure hosting infrastructure for businesses ready to scale.
          </p>
          <div className="flex gap-4">
            <Facebook className="w-5 h-5 cursor-pointer hover:text-orange-500 transition-colors" />
            <Twitter className="w-5 h-5 cursor-pointer hover:text-orange-500 transition-colors" />
            <Linkedin className="w-5 h-5 cursor-pointer hover:text-orange-500 transition-colors" />
            <Mail className="w-5 h-5 cursor-pointer hover:text-orange-500 transition-colors" />
          </div>
        </div>
        <div>
          <h4 className="text-white font-bold mb-6 uppercase text-[10px] tracking-widest">Support Resources</h4>
          <ul className="space-y-4 text-sm font-medium">
            <li className="hover:text-white cursor-pointer transition-colors">Help Documentation</li>
            <li className="hover:text-white cursor-pointer transition-colors">Submit a Ticket</li>
            <li className="hover:text-white cursor-pointer transition-colors">Service Status</li>
            <li className="hover:text-white cursor-pointer transition-colors">API Docs</li>
          </ul>
        </div>
        <div>
          <h4 className="text-white font-bold mb-6 uppercase text-[10px] tracking-widest">SkyPeak Portal</h4>
          <ul className="space-y-4 text-sm font-medium">
            <li className="hover:text-white cursor-pointer transition-colors">Privacy Policy</li>
            <li className="hover:text-white cursor-pointer transition-colors">Terms of Service</li>
            <li className="hover:text-white cursor-pointer transition-colors">Security Audit</li>
            <li className="hover:text-white cursor-pointer transition-colors">Contact Billing</li>
          </ul>
        </div>
      </div>
      <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-[10px] font-bold uppercase tracking-widest">
          &copy; 2025 SkyPeak Designs. All Rights Reserved.
        </p>
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-500" />
          <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Secure AES-256 Encrypted Session</span>
        </div>
      </div>
    </div>
  </footer>
);

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.DASHBOARD);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });

  const [clients, setClients] = useState<ClientData[]>([
    { 
      id: '1', 
      name: 'Tesla Corp', 
      username: 'tesla', 
      password: '123', 
      email: 'john@tesla.com',
      domain: 'tesla.com', 
      seoScore: 82, 
      seoImpressions: 42801,
      seoCTR: 4.2,
      seoTotalKeywords: 156,
      seoRankings: [
        { id: '1', term: 'Electric cars', rank: 1, change: '+2 POS' },
        { id: '2', term: 'Sustainable energy', rank: 2, change: '+2 POS' },
        { id: '3', term: 'Auto Pilot', rank: 3, change: '+2 POS' }
      ],
      trafficData: [40, 30, 45, 70, 65, 90],
      organicPercent: 65,
      directPercent: 20,
      referralPercent: 15,
      speedIndex: '0.8s',
      mobileUX: 'Excellent',
      domainExpiry: '2025-11-18', 
      serverExpiry: '2026-02-12',
      registrar: 'GoDaddy',
      serverIP: '54.212.18.243',
      serverLocation: 'Northern Virginia',
      phpVersion: '8.3.4',
      osVersion: 'Ubuntu 22.04 LTS',
      dbVersion: 'MariaDB 10.11',
      maintenanceStatus: 'Up to Date', 
      maintenancePlanName: 'Professional Care',
      maintenanceNextCharge: 'Nov 01, 2025',
      maintenanceSecurityScore: 100,
      maintenanceBackupStatus: '4 hours ago',
      maintenancePerformanceResponse: '0.8s',
      maintenanceTasks: [
        { id: '1', name: 'Core Engine Update', status: 'Completed', date: 'Oct 05, 2025', icon: 'Zap' },
        { id: '2', name: 'Security Patch Audit', status: 'Completed', date: 'Oct 05, 2025', icon: 'ShieldCheck' },
        { id: '3', name: 'Daily Cloud Backup', status: 'Active', date: 'Ongoing', icon: 'Database' },
        { id: '4', name: 'Database Optimization', status: 'Scheduled', date: 'Oct 15, 2025', icon: 'RefreshCw' },
        { id: '5', name: 'Plugin Compatibility Test', status: 'Scheduled', date: 'Oct 20, 2025', icon: 'Settings' },
      ],
      activityLog: [
        { id: '1', task: 'Security Patch Applied', date: '2 hours ago', icon: 'ShieldCheck', color: 'emerald' },
        { id: '2', task: 'Database Snapshot Complete', date: '6 hours ago', icon: 'Download', color: 'blue' }
      ],
      monthlyPrice: 149.00, 
      maintenancePrice: 100.00,
      invoices: [
        { id: 'INV-1001', date: 'Oct 01, 2025', amount: 249.00, status: 'Paid', type: 'SEO & Maintenance' },
        { id: 'INV-1000', date: 'Sep 01, 2025', amount: 249.00, status: 'Paid', type: 'SEO & Maintenance' }
      ],
      websitePayments: [
        { id: 'WS-101', title: 'Design & Prototype Phase', amount: 1500, status: 'Paid', date: 'Aug 15, 2025' },
        { id: 'WS-102', title: 'Development Kickoff', amount: 2500, status: 'Paid', date: 'Sep 10, 2025' },
        { id: 'WS-103', title: 'Final Deployment', amount: 2000, status: 'Pending', date: 'Oct 30, 2025' }
      ]
    }
  ]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const uname = loginForm.username.trim().toLowerCase();
    const pword = loginForm.password.trim();

    if (uname === 'admin' && pword === 'admin') {
      setUser({ id: '0', username: 'admin', role: 'ADMIN', email: 'admin@skypeak.com' });
      setActiveTab(AppTab.CLIENTS);
      return;
    }

    const foundClient = clients.find(c => c.username.toLowerCase() === uname && c.password === pword);
    if (foundClient) {
      setUser({ id: foundClient.id, username: foundClient.username, role: 'CLIENT', clientData: foundClient, email: foundClient.email });
      setActiveTab(AppTab.DASHBOARD);
    } else {
      alert('Invalid credentials.\nDemo Admin: admin / admin\nDemo Client: tesla / 123');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setActiveTab(AppTab.DASHBOARD);
  };

  const renderContent = () => {
    const currentClient = user?.clientData;
    switch (activeTab) {
      case AppTab.DASHBOARD: return <Dashboard clientData={currentClient} setActiveTab={setActiveTab} />;
      case AppTab.SEO: return <SEOSection clientData={currentClient} />;
      case AppTab.DOMAIN: return <DomainSection clientData={currentClient} />;
      case AppTab.HOSTING: return <HostingSection clientData={currentClient} />;
      case AppTab.PAYMENTS: return <PaymentsSection user={user!} clientData={currentClient} />;
      case AppTab.WEBSITE_PAYMENT: return <WebsitePaymentSection clientData={currentClient} />;
      case AppTab.MAINTENANCE: return <MaintenanceSection clientData={currentClient} />;
      case AppTab.HELP: return <SupportSection />;
      case AppTab.CLIENTS: return <AdminPanel clients={clients} setClients={setClients} />;
      case AppTab.SOURCE_CODE: return <SourceCode />;
      default: return user?.role === 'ADMIN' ? <AdminPanel clients={clients} setClients={setClients} /> : <Dashboard clientData={currentClient} setActiveTab={setActiveTab} />;
    }
  };

  const navItems = user?.role === 'ADMIN' 
    ? [{ id: AppTab.CLIENTS, icon: Users }, { id: AppTab.PAYMENTS, icon: CreditCard }, { id: AppTab.SOURCE_CODE, icon: Code }]
    : [
        { id: AppTab.DASHBOARD, icon: LayoutDashboard }, 
        { id: AppTab.DOMAIN, icon: Globe }, 
        { id: AppTab.HOSTING, icon: Server }, 
        { id: AppTab.PAYMENTS, icon: CreditCard },
        { id: AppTab.WEBSITE_PAYMENT, icon: Briefcase },
        { id: AppTab.SEO, icon: BarChart3 }, 
        { id: AppTab.MAINTENANCE, icon: Settings }, 
        { id: AppTab.HELP, icon: LifeBuoy }
      ];

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex flex-col items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-10 w-full max-w-md shadow-2xl">
          <div className="text-center mb-10">
            <img src={LOGO_URL} alt="SkyPeak Designs" className="h-14 mx-auto mb-6" />
            <h1 className="text-2xl font-black text-slate-900">Secure <span className="text-orange-500">Portal</span></h1>
            <p className="text-slate-500 text-sm mt-2 font-medium">Login to manage your digital presence</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Username</label>
              <div className="relative">
                <UserIcon className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
                <input type="text" value={loginForm.username} onChange={(e) => setLoginForm({...loginForm, username: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all" placeholder="e.g. tesla" />
              </div>
            </div>
            <div>
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
                <input type="password" value={loginForm.password} onChange={(e) => setLoginForm({...loginForm, password: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all" placeholder="••••••••" />
              </div>
            </div>
            <button className="w-full bg-orange-500 hover:bg-orange-600 text-white font-black py-4 rounded-xl transition-all shadow-lg shadow-orange-500/20 active:scale-95">Enter Dashboard</button>
          </form>
          <div className="mt-8 pt-8 border-t border-slate-100 flex flex-col items-center gap-2">
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Demo Accounts</p>
            <div className="flex gap-4 text-xs">
              <span className="text-slate-500">Admin: <b className="text-slate-900">admin / admin</b></span>
              <span className="text-slate-500">Client: <b className="text-slate-900">tesla / 123</b></span>
            </div>
          </div>
        </div>
        <p className="mt-8 text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em]">&copy; 2025 SkyPeak Designs</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-[#0f172a] text-white sticky top-0 z-50 shadow-2xl shadow-black/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-4">
              <img src={LOGO_URL} alt="SkyPeak Designs" className="h-10 w-auto" />
              <div className="h-8 w-px bg-slate-700 mx-1 hidden sm:block"></div>
              <span className="text-xl font-black tracking-tight hidden sm:block">Client <span className="text-orange-500">Panel</span></span>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold">{user.clientData?.name || user.username}</p>
                <p className="text-[10px] text-slate-400 uppercase tracking-widest font-black">{user.role}</p>
              </div>
              <button onClick={handleLogout} className="p-2.5 bg-slate-800 text-slate-400 hover:text-red-400 hover:bg-red-400/10 rounded-xl transition-all" title="Logout"><LogOut className="w-5 h-5" /></button>
            </div>
          </div>
        </div>
        <div className="bg-[#1e293b] border-t border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 overflow-x-auto no-scrollbar">
            <nav className="flex space-x-8 h-14">
              {navItems.map((item) => (
                <button key={item.id} onClick={() => setActiveTab(item.id)} className={`flex items-center gap-2 text-sm font-bold transition-all px-1 whitespace-nowrap relative ${activeTab === item.id ? 'text-orange-500' : 'text-slate-400 hover:text-white'}`}>
                  <item.icon className="w-4 h-4" />{item.id}
                  {activeTab === item.id && <span className="absolute bottom-0 left-0 w-full h-1 bg-orange-500 rounded-t-full shadow-[0_0_12px_rgba(249,115,22,0.8)]"></span>}
                </button>
              ))}
            </nav>
          </div>
        </div>
      </header>
      
      <main className="flex-1">
        <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
          {renderContent()}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default App;
